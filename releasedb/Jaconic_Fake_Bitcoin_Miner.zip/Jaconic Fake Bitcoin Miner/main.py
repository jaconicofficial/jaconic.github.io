#Jaconic Kriexpen bitcoin mining system private.
#Was made by Jaconic. All rights Reserved. (C) Jaconic 2021-2023.
#NOTE 1: This is only DESIGN version of a program. Wait for real release with working programs.
#NOTE 2: This program is in indev version now.
#NOTE 3: Do not modify the files of program and publish it like it's a new program! It's a bad idea!
#NOTE 4: In future, this program will be using another crypto vallets (and Blockchain too).
#NOTE 5 (extra to note 1): In future the working program can be look like this (or maybe not?).

import random

import library as lib

for x in range(10000):
	lib.mine(50) 

input("BITCOINS HASN'T FOUND ON THIS 10000 ACCOUNTS. RESTART PROGRAM FOR SECOND ATTEMPT")