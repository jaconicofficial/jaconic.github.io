import random



def mine(length):
    sample_string = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ001122334455667788'
    result = ''.join((random.choice(sample_string)) for x in range(length))
    print(result)

